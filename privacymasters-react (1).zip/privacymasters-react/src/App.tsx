import './design-system.css'

export default function App() {
  return (
    <>
      <PageHeader />
      <TableOfContents />
      <main>
        <Screenshots />
        <Brand />
        <Colors />
        <Typography />
        <CallsToAction />
        <Badges />
        <Cards />
        <FormFields />
        <VisualEffects />
        <Layout />
        <CssVariables />
      </main>
    </>
  )
}

function PageHeader() {
  return (
    <header className={"top"}>
      <h1>{"privacymasters.it — design system attuale"}</h1>
      <p>{"Privacy Masters — Cybersecurity, GDPR, NIS2 | Rovigo, Veneto"}</p>
      <p className={"mono"}>{"Estratto il 2026-11-23 · homepage + 3 pagine interne · desktop 1440px e mobile 390px · valori computati dal browser (non dal sorgente)"}</p>
    </header>
  )
}

function TableOfContents() {
  return (
    <nav className={"toc"}>
      <a href={"#shot"}>{"Screenshot"}</a>
      <a href={"#logo"}>{"Logo"}</a>
      <a href={"#col"}>{"Colori"}</a>
      <a href={"#typo"}>{"Tipografia"}</a>
      <a href={"#btn"}>{"CTA"}</a>
      <a href={"#badge"}>{"Badge"}</a>
      <a href={"#card"}>{"Card"}</a>
      <a href={"#form"}>{"Form"}</a>
      <a href={"#fx"}>{"Raggi, ombre, gradienti"}</a>
      <a href={"#layout"}>{"Layout"}</a>
      <a href={"#vars"}>{"Variabili"}</a>
    </nav>
  )
}

function Screenshots() {
  return (
    <section id={"shot"}>
      <h2>{"Screenshot homepage"}</h2>
      <div className={"shots"}>
        <img src={"desktop-fold.png"} alt="" />
        <img src={"mobile-fold.png"} alt="" />
      </div>
      <p className={"muted"}>
        {"Pagina intera: "}
        <a href={"desktop-full.png"}>{"desktop"}</a>
        {" · "}
        <a href={"mobile-full.png"}>{"mobile"}</a>
      </p>
      <h3>{"Pagine interne"}</h3>
      <div className={"inner"}>
        <figure>
          <img src={"inner-1-fold.png"} alt="" />
          <figcaption>
            <a href={"inner-1-full.png"}>{"/contatti"}</a>
            {" — Contatti — Privacy Masters · Rovigo (Veneto)"}
          </figcaption>
        </figure>
        <figure>
          <img src={"inner-2-fold.png"} alt="" />
          <figcaption>
            <a href={"inner-2-full.png"}>{"/servizi"}</a>
            {" — Servizi — GDPR, Cybersecurity, NIS2, DORA | Privacy Masters"}
          </figcaption>
        </figure>
        <figure>
          <img src={"inner-3-fold.png"} alt="" />
          <figcaption>
            <a href={"inner-3-full.png"}>{"/blog"}</a>
            {" — Blog normativo GDPR, NIS2, DORA, AI Act | Privacy Masters"}
          </figcaption>
        </figure>
      </div>
      <h3>{"Header e footer"}</h3>
      <img src={"header.png"} style={{"width": "100%", "border": "1px solid var(--line)"}} alt="" />
      <br />
      <br />
      <img src={"footer.png"} style={{"width": "100%", "border": "1px solid var(--line)"}} alt="" />
    </section>
  )
}

function Brand() {
  return (
    <section id={"logo"}>
      <h2>{"Logo e marchio"}</h2>
      <div className={"logos"}>
        <div className={"logo-cell"} style={{"background": "#fff", "border": "1px solid var(--line)"}}>
          <img src={"logo-lockup.png"} style={{"maxHeight": "72px"}} alt="" />
          <small>{"lockup come appare nell'header"}</small>
        </div>
        <div className={"logo-cell"}>
          <img src={"https://privacymasters.it/assets/logo-BgtPAKuu.png"} style={{"maxWidth": "220px", "maxHeight": "80px"}} alt="" />
          <small className={"mono"}>{"logo-BgtPAKuu.png · reso 32×36px"}</small>
        </div>
        <div className={"logo-cell"}>
          <div style={{"display": "flex", "gap": "8px"}}>
            <img src={"https://privacymasters.it/favicon.ico"} style={{"width": "32px", "height": "32px"}} title={"https://privacymasters.it/favicon.ico"} alt="" />
            <img src={"https://privacymasters.it/favicon-32.png"} style={{"width": "32px", "height": "32px"}} title={"https://privacymasters.it/favicon-32.png"} alt="" />
            <img src={"https://privacymasters.it/favicon-16.png"} style={{"width": "32px", "height": "32px"}} title={"https://privacymasters.it/favicon-16.png"} alt="" />
          </div>
          <small>{"favicon"}</small>
        </div>
      </div>
    </section>
  )
}

function Colors() {
  return (
    <section id={"col"}>
      <h2>{"Colori"}</h2>
      <h3>{"Sfondi (peso = area occupata)"}</h3>
      <div className={"sws"}>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#FFFFFF", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#FFFFFF"}</code>
          <small>{"51.4% area"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#F5F9FA", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#F5F9FA"}</code>
          <small>{"29.5% area"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#0A2B33", "color": "#fff"}}>{"Aa"}</div>
          </div>
          <code>{"#0A2B33"}</code>
          <small>{"10.9% area"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#00C4890D", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#00C489 · α0.05"}</code>
          <small>{"4.3% area"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#FFFFFFB2", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#FFFFFF · α0.7"}</code>
          <small>{"2.1% area"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#00C483", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#00C483"}</code>
          <small>{"0.8% area"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#00C4801A", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#00C480 · α0.1"}</code>
          <small>{"0.6% area"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#FFFFFFCC", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#FFFFFF · α0.8"}</code>
          <small>{"0.3% area"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#F5F9F980", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#F5F9F9 · α0.5"}</code>
          <small>{"0.2% area"}</small>
        </div>
      </div>
      <h3>{"Testo (peso = caratteri)"}</h3>
      <div className={"sws"}>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#0A2B33", "color": "#fff"}}>{"Aa"}</div>
          </div>
          <code>{"#0A2B33"}</code>
          <small>{"36.5% testo"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#55666F", "color": "#fff"}}>{"Aa"}</div>
          </div>
          <code>{"#55666F"}</code>
          <small>{"32.7% testo"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#FFFFFF80", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#FFFFFF · α0.5"}</code>
          <small>{"11.2% testo"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#FFFFFFB2", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#FFFFFF · α0.7"}</code>
          <small>{"7.6% testo"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#00C483", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#00C483"}</code>
          <small>{"6.4% testo"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#FFFFFF99", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#FFFFFF · α0.6"}</code>
          <small>{"2.2% testo"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#FFFFFF", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#FFFFFF"}</code>
          <small>{"2.1% testo"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#55666FCC", "color": "#fff"}}>{"Aa"}</div>
          </div>
          <code>{"#55666F · α0.8"}</code>
          <small>{"0.9% testo"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#FFFFFFCC", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#FFFFFF · α0.8"}</code>
          <small>{"0.4% testo"}</small>
        </div>
      </div>
      <h3>{"Bordi"}</h3>
      <div className={"sws"}>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#D8DFE3", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#D8DFE3"}</code>
          <small>{"83.8% bordi"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#00C3814D", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#00C381 · α0.3"}</code>
          <small>{"15.0% bordi"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#00C38266", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#00C382 · α0.4"}</code>
          <small>{"0.6% bordi"}</small>
        </div>
        <div className={"sw"}>
          <div className={"chip checker"}>
            <div style={{"background": "#FFFFFF1A", "color": "#111"}}>{"Aa"}</div>
          </div>
          <code>{"#FFFFFF · α0.1"}</code>
          <small>{"0.6% bordi"}</small>
        </div>
      </div>
      <h3>{"Contrasto (WCAG 2.1)"}</h3>
      <table>
        <tbody>
          <tr>
            <th>{"Primo piano"}</th>
            <th>{"Sfondo"}</th>
            <th>{"Rapporto"}</th>
            <th>{"Esito"}</th>
          </tr>
          <tr>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              {"#0A2B33"}
            </td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              {"#FFFFFF"}
            </td>
            <td>{"14.93"}</td>
            <td>{"AA ✓"}</td>
          </tr>
          <tr>
            <td>
              <span className={"dot"} style={{"background": "#55666F"}}></span>
              {"#55666F"}
            </td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              {"#FFFFFF"}
            </td>
            <td>{"5.97"}</td>
            <td>{"AA ✓"}</td>
          </tr>
          <tr>
            <td>
              <span className={"dot"} style={{"background": "#00C483"}}></span>
              {"#00C483"}
            </td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              {"#FFFFFF"}
            </td>
            <td>{"2.28"}</td>
            <td>{"insufficiente"}</td>
          </tr>
          <tr>
            <td>
              {"CTA «Check-up gratuito» "}
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              {"#FFFFFF"}
            </td>
            <td>
              <span className={"dot"} style={{"background": "#00C483"}}></span>
              {"#00C483"}
            </td>
            <td>{"2.28"}</td>
            <td>{"insufficiente"}</td>
          </tr>
          <tr>
            <td>
              {"CTA «Richiedi check-up gr» "}
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              {"#FFFFFF"}
            </td>
            <td>
              <span className={"dot"} style={{"background": "#00C483"}}></span>
              {"#00C483"}
            </td>
            <td>{"2.28"}</td>
            <td>{"insufficiente"}</td>
          </tr>
          <tr>
            <td>
              {"CTA «Parla con un esperto» "}
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              {"#0A2B33"}
            </td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              {"#FFFFFF"}
            </td>
            <td>{"14.93"}</td>
            <td>{"AA ✓"}</td>
          </tr>
          <tr>
            <td>
              {"CTA «Scopri il tuo livell» "}
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              {"#FFFFFF"}
            </td>
            <td>
              <span className={"dot"} style={{"background": "#00C483"}}></span>
              {"#00C483"}
            </td>
            <td>{"2.28"}</td>
            <td>{"insufficiente"}</td>
          </tr>
          <tr>
            <td>
              {"CTA «Prenota il tuo check» "}
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              {"#FFFFFF"}
            </td>
            <td>
              <span className={"dot"} style={{"background": "#00C483"}}></span>
              {"#00C483"}
            </td>
            <td>{"2.28"}</td>
            <td>{"insufficiente"}</td>
          </tr>
          <tr>
            <td>
              {"CTA «Accetta e mostra la » "}
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              {"#FFFFFF"}
            </td>
            <td>
              <span className={"dot"} style={{"background": "#00C483"}}></span>
              {"#00C483"}
            </td>
            <td>{"2.28"}</td>
            <td>{"insufficiente"}</td>
          </tr>
        </tbody>
      </table>
    </section>
  )
}

function Typography() {
  return (
    <section id={"typo"}>
      <h2>{"Tipografia"}</h2>
      <p>
        <b>{"Famiglie usate:"}</b>
        {" "}
        <code>{"Inter"}</code>
        {", "}
        <code>{"Poppins"}</code>
        {" · "}
        <b>{"Pesi:"}</b>
        {" 400, 500, 600, 700 · "}
        <b>{"Dimensioni (px):"}</b>
        {" 11 · 12 · 14 · 16 · 18 · 20 · 24 · 30 · 36 · 48 · 60 · 72"}
      </p>
      <p>
        <b>{"Mobile:"}</b>
        {" H1 36px/40px, H2 30px/36px, H3 18px/28px · body 16px · "}
        <b>{"Nav:"}</b>
        {" {\"font\": \"Inter\", \"size\": \"14px\", \"weight\": \"500\", \"color\": \"#55666F\", \"transform\": \"none\", \"ls\": \"normal\"}"}
      </p>
      <div className={"spec"}>
        <div className={"spec-meta"}>
          <b>{"H1"}</b>
          <code>{"Poppins"}</code>
          <code>{"72px / 72px"}</code>
          <code>{"w700"}</code>
          <code>{"ls -1.8px"}</code>
          <code>
            <span className={"dot"} style={{"background": "#0A2B33"}}></span>
            {"#0A2B33"}
          </code>
        </div>
        <div style={{"fontFamily": "'Poppins', 'Poppins', system-ui, sans-serif", "fontSize": "72px", "lineHeight": "72px", "fontWeight": "700", "color": "#0A2B33", "textTransform": "none", "letterSpacing": "-1.8px"}}>{"Protezione totale. Zero compromessi."}</div>
      </div>
      <div className={"spec"}>
        <div className={"spec-meta"}>
          <b>{"H2"}</b>
          <code>{"Poppins"}</code>
          <code>{"48px / 48px"}</code>
          <code>{"w700"}</code>
          <code>{"ls -1.2px"}</code>
          <code>
            <span className={"dot"} style={{"background": "#0A2B33"}}></span>
            {"#0A2B33"}
          </code>
        </div>
        <div style={{"fontFamily": "'Poppins', 'Poppins', system-ui, sans-serif", "fontSize": "48px", "lineHeight": "48px", "fontWeight": "700", "color": "#0A2B33", "textTransform": "none", "letterSpacing": "-1.2px"}}>{"I numeri della cybersicurezza in Italia"}</div>
      </div>
      <div className={"spec"}>
        <div className={"spec-meta"}>
          <b>{"H3"}</b>
          <code>{"Poppins"}</code>
          <code>{"18px / 28px"}</code>
          <code>{"w600"}</code>
          <code>{"ls -0.36px"}</code>
          <code>
            <span className={"dot"} style={{"background": "#0A2B33"}}></span>
            {"#0A2B33"}
          </code>
        </div>
        <div style={{"fontFamily": "'Poppins', 'Poppins', system-ui, sans-serif", "fontSize": "18px", "lineHeight": "28px", "fontWeight": "600", "color": "#0A2B33", "textTransform": "none", "letterSpacing": "-0.36px"}}>{"Ransomware"}</div>
      </div>
      <div className={"spec"}>
        <div className={"spec-meta"}>
          <b>{"BODY LEAD"}</b>
          <code>{"Inter"}</code>
          <code>{"20px / 32.5px"}</code>
          <code>{"w400"}</code>
          <code>
            <span className={"dot"} style={{"background": "#55666F"}}></span>
            {"#55666F"}
          </code>
        </div>
        <div style={{"fontFamily": "'Inter', 'Inter', system-ui, sans-serif", "fontSize": "20px", "lineHeight": "32.5px", "fontWeight": "400", "color": "#55666F", "maxWidth": "70ch"}}>{"Cybersecurity, privacy, investigazione e sicurezza fisica. Un unico team operativo — avvocati, ethical hacker, investigatori e ingegneri — per difendere aziende"}</div>
      </div>
      <h3>{"Stili di testo più usati (homepage)"}</h3>
      <table>
        <tbody>
          <tr>
            <th>{"tag"}</th>
            <th>{"font"}</th>
            <th>{"size"}</th>
            <th>{"peso"}</th>
            <th>{"interlinea"}</th>
            <th>{"spaziatura"}</th>
            <th>{"colore"}</th>
            <th>{"case"}</th>
            <th>{"car."}</th>
            <th>{"esempio"}</th>
          </tr>
          <tr>
            <td>{"p"}</td>
            <td>{"Inter"}</td>
            <td>{"14px"}</td>
            <td>{"400"}</td>
            <td>{"22.75px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#55666F"}}></span>
              {"#55666F"}
            </td>
            <td></td>
            <td>{"2518"}</td>
            <td className={"sample"}>{"Crescita attacchi gravi in Italia (2019→2024)"}</td>
          </tr>
          <tr>
            <td>{"p"}</td>
            <td>{"Inter"}</td>
            <td>{"18px"}</td>
            <td>{"400"}</td>
            <td>{"29.25px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#55666F"}}></span>
              {"#55666F"}
            </td>
            <td></td>
            <td>{"609"}</td>
            <td className={"sample"}>{"Dati ufficiali aggregati da Clusit, ACN, Garante"}</td>
          </tr>
          <tr>
            <td>{"span"}</td>
            <td>{"Inter"}</td>
            <td>{"14px"}</td>
            <td>{"500"}</td>
            <td>{"20px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              {"#0A2B33"}
            </td>
            <td></td>
            <td>{"543"}</td>
            <td className={"sample"}>{"ISO/IEC 27001:2022 — Sistemi di gestione della s"}</td>
          </tr>
          <tr>
            <td>{"p"}</td>
            <td>{"Inter"}</td>
            <td>{"12px"}</td>
            <td>{"400"}</td>
            <td>{"19.5px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF80"}}></span>
              {"#FFFFFF80"}
            </td>
            <td></td>
            <td>{"477"}</td>
            <td className={"sample"}>{"I contenuti del sito hanno finalità informative "}</td>
          </tr>
          <tr>
            <td>{"h2"}</td>
            <td>{"Poppins"}</td>
            <td>{"48px"}</td>
            <td>{"700"}</td>
            <td>{"48px"}</td>
            <td>{"-1.2px"}</td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              {"#0A2B33"}
            </td>
            <td></td>
            <td>{"223"}</td>
            <td className={"sample"}>{"I numeri della cybersicurezza in Italia"}</td>
          </tr>
          <tr>
            <td>{"p"}</td>
            <td>{"Inter"}</td>
            <td>{"20px"}</td>
            <td>{"400"}</td>
            <td>{"32.5px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#55666F"}}></span>
              {"#55666F"}
            </td>
            <td></td>
            <td>{"213"}</td>
            <td className={"sample"}>{"Cybersecurity, privacy, investigazione e sicurez"}</td>
          </tr>
          <tr>
            <td>{"span"}</td>
            <td>{"Poppins"}</td>
            <td>{"18px"}</td>
            <td>{"600"}</td>
            <td>{"28px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              {"#0A2B33"}
            </td>
            <td></td>
            <td>{"198"}</td>
            <td className={"sample"}>{"La mia azienda è obbligata ad applicare la NIS2?"}</td>
          </tr>
          <tr>
            <td>{"p"}</td>
            <td>{"Inter"}</td>
            <td>{"11px"}</td>
            <td>{"500"}</td>
            <td>{"16.5px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#55666FCC"}}></span>
              {"#55666FCC"}
            </td>
            <td></td>
            <td>{"187"}</td>
            <td className={"sample"}>{"Clusit – Rapporto 2025"}</td>
          </tr>
          <tr>
            <td>{"p"}</td>
            <td>{"Inter"}</td>
            <td>{"16px"}</td>
            <td>{"400"}</td>
            <td>{"26px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#55666F"}}></span>
              {"#55666F"}
            </td>
            <td></td>
            <td>{"172"}</td>
            <td className={"sample"}>{"Le competenze del team derivano da esperienze ma"}</td>
          </tr>
          <tr>
            <td>{"h3"}</td>
            <td>{"Poppins"}</td>
            <td>{"18px"}</td>
            <td>{"600"}</td>
            <td>{"28px"}</td>
            <td>{"-0.36px"}</td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              {"#0A2B33"}
            </td>
            <td></td>
            <td>{"146"}</td>
            <td className={"sample"}>{"Ransomware"}</td>
          </tr>
          <tr>
            <td>{"h3"}</td>
            <td>{"Poppins"}</td>
            <td>{"16px"}</td>
            <td>{"600"}</td>
            <td>{"24px"}</td>
            <td>{"-0.32px"}</td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              {"#0A2B33"}
            </td>
            <td></td>
            <td>{"146"}</td>
            <td className={"sample"}>{"Pubblica Amministrazione"}</td>
          </tr>
          <tr>
            <td>{"a"}</td>
            <td>{"Inter"}</td>
            <td>{"14px"}</td>
            <td>{"400"}</td>
            <td>{"20px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFFB2"}}></span>
              {"#FFFFFFB2"}
            </td>
            <td></td>
            <td>{"130"}</td>
            <td className={"sample"}>{"Chi siamo"}</td>
          </tr>
          <tr>
            <td>{"p"}</td>
            <td>{"Inter"}</td>
            <td>{"14px"}</td>
            <td>{"400"}</td>
            <td>{"22.75px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFFB2"}}></span>
              {"#FFFFFFB2"}
            </td>
            <td></td>
            <td>{"115"}</td>
            <td className={"sample"}>{"Cybersecurity, privacy, investigazione e sicurez"}</td>
          </tr>
          <tr>
            <td>{"p"}</td>
            <td>{"Poppins"}</td>
            <td>{"24px"}</td>
            <td>{"600"}</td>
            <td>{"32px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              {"#0A2B33"}
            </td>
            <td></td>
            <td>{"108"}</td>
            <td className={"sample"}>{"“Il problema non è se succederà. Ma quando.”"}</td>
          </tr>
          <tr>
            <td>{"li"}</td>
            <td>{"Inter"}</td>
            <td>{"12px"}</td>
            <td>{"400"}</td>
            <td>{"19.5px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFFB2"}}></span>
              {"#FFFFFFB2"}
            </td>
            <td></td>
            <td>{"101"}</td>
            <td className={"sample"}>{"Ragione sociale: Evolve S.r.l."}</td>
          </tr>
          <tr>
            <td>{"span"}</td>
            <td>{"Inter"}</td>
            <td>{"12px"}</td>
            <td>{"600"}</td>
            <td>{"16px"}</td>
            <td>{"0.6px"}</td>
            <td>
              <span className={"dot"} style={{"background": "#00C483"}}></span>
              {"#00C483"}
            </td>
            <td>{"uppercase"}</td>
            <td>{"87"}</td>
            <td className={"sample"}>{"Difesa integrata 360°"}</td>
          </tr>
          <tr>
            <td>{"a"}</td>
            <td>{"Inter"}</td>
            <td>{"14px"}</td>
            <td>{"600"}</td>
            <td>{"20px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              {"#FFFFFF"}
            </td>
            <td></td>
            <td>{"75"}</td>
            <td className={"sample"}>{"Check-up gratuito"}</td>
          </tr>
          <tr>
            <td>{"p"}</td>
            <td>{"Inter"}</td>
            <td>{"18px"}</td>
            <td>{"400"}</td>
            <td>{"28px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFFCC"}}></span>
              {"#FFFFFFCC"}
            </td>
            <td></td>
            <td>{"73"}</td>
            <td className={"sample"}>{"Un check-up gratuito può evitarti danni da centi"}</td>
          </tr>
          <tr>
            <td>{"p"}</td>
            <td>{"Inter"}</td>
            <td>{"12px"}</td>
            <td>{"400"}</td>
            <td>{"16px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF99"}}></span>
              {"#FFFFFF99"}
            </td>
            <td></td>
            <td>{"68"}</td>
            <td className={"sample"}>{"© 2026 Evolve S.r.l. — Privacy Masters. Tutti i "}</td>
          </tr>
          <tr>
            <td>{"dd"}</td>
            <td>{"Inter"}</td>
            <td>{"11px"}</td>
            <td>{"400"}</td>
            <td>{"16.5px"}</td>
            <td>{"0.55px"}</td>
            <td>
              <span className={"dot"} style={{"background": "#55666F"}}></span>
              {"#55666F"}
            </td>
            <td>{"uppercase"}</td>
            <td>{"65"}</td>
            <td className={"sample"}>{"Aree integrate"}</td>
          </tr>
          <tr>
            <td>{"a"}</td>
            <td>{"Inter"}</td>
            <td>{"14px"}</td>
            <td>{"500"}</td>
            <td>{"20px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#55666F"}}></span>
              {"#55666F"}
            </td>
            <td></td>
            <td>{"60"}</td>
            <td className={"sample"}>{"Home"}</td>
          </tr>
          <tr>
            <td>{"h3"}</td>
            <td>{"Poppins"}</td>
            <td>{"20px"}</td>
            <td>{"600"}</td>
            <td>{"28px"}</td>
            <td>{"-0.4px"}</td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              {"#0A2B33"}
            </td>
            <td></td>
            <td>{"59"}</td>
            <td className={"sample"}>{"Analisi del rischio"}</td>
          </tr>
          <tr>
            <td>{"p"}</td>
            <td>{"Inter"}</td>
            <td>{"12px"}</td>
            <td>{"400"}</td>
            <td>{"16px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF80"}}></span>
              {"#FFFFFF80"}
            </td>
            <td></td>
            <td>{"53"}</td>
            <td className={"sample"}>{"Privacy Masters è un brand operativo di Evolve S"}</td>
          </tr>
          <tr>
            <td>{"span"}</td>
            <td>{"Inter"}</td>
            <td>{"14px"}</td>
            <td>{"600"}</td>
            <td>{"20px"}</td>
            <td></td>
            <td>
              <span className={"dot"} style={{"background": "#00C483"}}></span>
              {"#00C483"}
            </td>
            <td></td>
            <td>{"52"}</td>
            <td className={"sample"}>{"Scopri di più"}</td>
          </tr>
        </tbody>
      </table>
    </section>
  )
}

function CallsToAction() {
  return (
    <section id={"btn"}>
      <h2>{"Pulsanti e CTA (sul loro sfondo reale)"}</h2>
      <div className={"btns"}>
        <div className={"btn-cell"}>
          <div className={"btn-stage"} style={{"background": "#FFFFFF"}}>
            <a style={{"display": "inline-flex", "alignItems": "center", "gap": "8px", "justifyContent": "center", "background": "#00C483", "color": "#FFFFFF", "borderRadius": "9999px", "border": "none", "padding": "8px 16px", "fontFamily": "'Inter', 'Inter', system-ui, sans-serif", "fontSize": "14px", "fontWeight": "600", "textTransform": "none", "letterSpacing": "normal", "boxShadow": "#00C38340 0px 4px 6px -1px, #00C38340 0px 2px 4px -2px", "height": "36px", "textDecoration": "none", "whiteSpace": "nowrap"}}>{"Check-up gratuito →"}</a>
          </div>
          <small className={"mono"}>{"bg #00C483 · testo #FFFFFF · r 9999px · 14px/600 · h36 · pad 8px 16px"}</small>
        </div>
        <div className={"btn-cell"}>
          <div className={"btn-stage"} style={{"background": "#FFFFFF"}}>
            <a style={{"display": "inline-flex", "alignItems": "center", "gap": "8px", "justifyContent": "center", "background": "#00C483", "color": "#FFFFFF", "borderRadius": "9999px", "border": "none", "padding": "14px 24px", "fontFamily": "'Inter', 'Inter', system-ui, sans-serif", "fontSize": "14px", "fontWeight": "600", "textTransform": "none", "letterSpacing": "normal", "boxShadow": "#00C3814D 0px 10px 15px -3px, #00C3814D 0px 4px 6px -4px", "height": "48px", "textDecoration": "none", "whiteSpace": "nowrap"}}>{"Richiedi check-up gratuito →"}</a>
          </div>
          <small className={"mono"}>{"bg #00C483 · testo #FFFFFF · r 9999px · 14px/600 · h48 · pad 14px 24px"}</small>
        </div>
        <div className={"btn-cell"}>
          <div className={"btn-stage"} style={{"background": "#FFFFFF"}}>
            <a style={{"display": "inline-flex", "alignItems": "center", "gap": "8px", "justifyContent": "center", "background": "#FFFFFF", "color": "#0A2B33", "borderRadius": "9999px", "border": "1px solid #D8DFE3", "padding": "14px 24px", "fontFamily": "'Inter', 'Inter', system-ui, sans-serif", "fontSize": "14px", "fontWeight": "600", "textTransform": "none", "letterSpacing": "normal", "height": "50px", "textDecoration": "none", "whiteSpace": "nowrap"}}>{"Parla con un esperto"}</a>
          </div>
          <small className={"mono"}>{"bg #FFFFFF · testo #0A2B33 · r 9999px · 14px/600 · h50 · pad 14px 24px · bordo 1px solid #D8DFE3"}</small>
        </div>
        <div className={"btn-cell"}>
          <div className={"btn-stage"} style={{"background": "#FFFFFF"}}>
            <a style={{"display": "inline-flex", "alignItems": "center", "gap": "8px", "justifyContent": "center", "background": "#00C483", "color": "#FFFFFF", "borderRadius": "9999px", "border": "none", "padding": "12px 24px", "fontFamily": "'Inter', 'Inter', system-ui, sans-serif", "fontSize": "14px", "fontWeight": "600", "textTransform": "none", "letterSpacing": "normal", "boxShadow": "#00C38340 0px 4px 6px -1px, #00C38340 0px 2px 4px -2px", "height": "44px", "textDecoration": "none", "whiteSpace": "nowrap"}}>{"Scopri il tuo livello di rischio →"}</a>
          </div>
          <small className={"mono"}>{"bg #00C483 · testo #FFFFFF · r 9999px · 14px/600 · h44 · pad 12px 24px"}</small>
        </div>
        <div className={"btn-cell"}>
          <div className={"btn-stage"} style={{"background": "#0A2B33"}}>
            <a style={{"display": "inline-flex", "alignItems": "center", "gap": "8px", "justifyContent": "center", "background": "#00C483", "color": "#FFFFFF", "borderRadius": "9999px", "border": "none", "padding": "16px 28px", "fontFamily": "'Inter', 'Inter', system-ui, sans-serif", "fontSize": "16px", "fontWeight": "600", "textTransform": "none", "letterSpacing": "normal", "boxShadow": "#00C38266 0px 20px 25px -5px, #00C38266 0px 8px 10px -6px", "height": "56px", "textDecoration": "none", "whiteSpace": "nowrap"}}>{"Prenota il tuo check-up gratuito →"}</a>
          </div>
          <small className={"mono"}>{"bg #00C483 · testo #FFFFFF · r 9999px · 16px/600 · h56 · pad 16px 28px"}</small>
        </div>
        <div className={"btn-cell"}>
          <div className={"btn-stage"} style={{"background": "#FFFFFF"}}>
            <a style={{"display": "inline-flex", "alignItems": "center", "gap": "8px", "justifyContent": "center", "background": "#00C483", "color": "#FFFFFF", "borderRadius": "9999px", "border": "none", "padding": "10px 20px", "fontFamily": "'Inter', 'Inter', system-ui, sans-serif", "fontSize": "14px", "fontWeight": "600", "textTransform": "none", "letterSpacing": "normal", "boxShadow": "#0000001A 0px 1px 3px 0px, #0000001A 0px 1px 2px -1px", "height": "40px", "textDecoration": "none", "whiteSpace": "nowrap"}}>{"Accetta e mostra la mappa"}</a>
          </div>
          <small className={"mono"}>{"bg #00C483 · testo #FFFFFF · r 9999px · 14px/600 · h40 · pad 10px 20px"}</small>
        </div>
      </div>
    </section>
  )
}

function Badges() {
  return (
    <section id={"badge"}>
      <h2>{"Badge ed etichette"}</h2>
      <div className={"btns"}>
        <div className={"btn-cell"}>
          <span style={{"display": "inline-flex", "alignItems": "center", "background": "#00C4801A", "color": "#00C483", "border": "1px solid #00C38266", "borderRadius": "9999px", "padding": "4px 12px", "fontSize": "12px", "fontWeight": "600", "textTransform": "uppercase", "letterSpacing": "0.6px", "fontFamily": "'Inter', 'Inter', system-ui, sans-serif"}}>{"Difesa integrata 360°"}</span>
          <small className={"mono"}>{"bg #00C4801A · #00C483 · r 9999px"}</small>
        </div>
        <div className={"btn-cell"}>
          <span style={{"display": "inline-flex", "alignItems": "center", "background": "#00C4801A", "color": "#00C483", "border": "1px solid #00C3814D", "borderRadius": "9999px", "padding": "4px 12px", "fontSize": "12px", "fontWeight": "600", "textTransform": "uppercase", "letterSpacing": "0.6px", "fontFamily": "'Inter', 'Inter', system-ui, sans-serif"}}>{"Dati 2024"}</span>
          <small className={"mono"}>{"bg #00C4801A · #00C483 · r 9999px"}</small>
        </div>
        <div className={"btn-cell"}>
          <span style={{"display": "inline-flex", "alignItems": "center", "background": "#FFFFFF", "color": "#0A2B33", "border": "1px solid #D8DFE3", "borderRadius": "9999px", "padding": "8px 16px", "fontSize": "14px", "fontWeight": "500", "textTransform": "none", "letterSpacing": "normal", "fontFamily": "'Inter', 'Inter', system-ui, sans-serif"}}>{"Ex appartenenti alle Forze dell'Ordine"}</span>
          <small className={"mono"}>{"bg #FFFFFF · #0A2B33 · r 9999px"}</small>
        </div>
        <div className={"btn-cell"}>
          <span style={{"display": "inline-flex", "alignItems": "center", "background": "#00000000", "color": "#55666F", "border": "1px solid #D8DFE3", "borderRadius": "9999px", "padding": "0px", "fontSize": "12px", "fontWeight": "400", "textTransform": "none", "letterSpacing": "normal", "fontFamily": "'Inter', 'Inter', system-ui, sans-serif"}}>{"+"}</span>
          <small className={"mono"}>{"bg #00000000 · #55666F · r 9999px"}</small>
        </div>
        <div className={"btn-cell"}>
          <span style={{"display": "inline-flex", "alignItems": "center", "background": "#00C4801A", "color": "#00C483", "border": "1px solid #00C3814D", "borderRadius": "9999px", "padding": "2px 10px", "fontSize": "12px", "fontWeight": "600", "textTransform": "none", "letterSpacing": "normal", "fontFamily": "'Inter', 'Inter', system-ui, sans-serif"}}>{"NIS2"}</span>
          <small className={"mono"}>{"bg #00C4801A · #00C483 · r 9999px"}</small>
        </div>
      </div>
    </section>
  )
}

function Cards() {
  return (
    <section id={"card"}>
      <h2>{"Card"}</h2>
      <div className={"cards"}>
        <div className={"card-cell"}>
          <div style={{"background": "#FFFFFF", "border": "1px solid #D8DFE3", "borderRadius": "18px", "boxShadow": "#0033330A 0px 1px 2px 0px, #1133330F 0px 4px 12px -2px", "padding": "24px", "height": "150px", "overflow": "hidden", "fontSize": "13px", "color": "#445"}}>{"+65%Crescita attacchi gravi in Italia (2019→2024)Clusit – Rapporto 2025"}</div>
          <small className={"mono"}>{"bg #FFFFFF · r 18px · pad 24px · bordo 1px solid #D8DFE3 · ombra #0033330A 0px 1px 2px 0px, #1133330F 0px 4px 12px -2px"}</small>
        </div>
        <div className={"card-cell"}>
          <div style={{"background": "#FFFFFF", "border": "1px solid #D8DFE3", "borderRadius": "22px", "boxShadow": "#0033330A 0px 1px 2px 0px, #1133330F 0px 4px 12px -2px", "padding": "40px", "height": "150px", "overflow": "hidden", "fontSize": "13px", "color": "#445"}}>{"ScriviciNomeEmailTelefonoMessaggioHo letto la privacy policy e acconsento al tra"}</div>
          <small className={"mono"}>{"bg #FFFFFF · r 22px · pad 40px · bordo 1px solid #D8DFE3 · ombra #0033330A 0px 1px 2px 0px, #1133330F 0px 4px 12px -2px"}</small>
        </div>
        <div className={"card-cell"}>
          <div style={{"background": "#F5F9FA", "border": "1px solid #D8DFE3", "borderRadius": "14px", "padding": "16px", "height": "150px", "overflow": "hidden", "fontSize": "13px", "color": "#445"}}>{"A chi serveAziende di ogni dimensione, PA, sanità, terzo settore, studi professi"}</div>
          <small className={"mono"}>{"bg #F5F9FA · r 14px · pad 16px · bordo 1px solid #D8DFE3"}</small>
        </div>
        <div className={"card-cell"}>
          <div style={{"background": "#00C4890D", "border": "1px solid #00C3814D", "borderRadius": "18px", "padding": "20px", "height": "150px", "overflow": "hidden", "fontSize": "13px", "color": "#445"}}>{"DeliverableRegistro dei trattamenti (art. 30) e analisi gap GDPRInformative, con"}</div>
          <small className={"mono"}>{"bg #00C4890D · r 18px · pad 20px · bordo 1px solid #00C3814D"}</small>
        </div>
        <div className={"card-cell"}>
          <div style={{"background": "#F5F9FA", "border": "1px solid #D8DFE3", "borderRadius": "18px", "padding": "20px", "height": "150px", "overflow": "hidden", "fontSize": "13px", "color": "#445"}}>{"Domande frequentiIn quanto tempo partite con l'incarico di DPO?Cosa devo prepara"}</div>
          <small className={"mono"}>{"bg #F5F9FA · r 18px · pad 20px · bordo 1px solid #D8DFE3"}</small>
        </div>
      </div>
    </section>
  )
}

function FormFields() {
  return (
    <section id={"form"}>
      <h2>{"Campi form"}</h2>
      <div className={"btns"}>
        <div className={"btn-cell"}>
          <input placeholder={"text"} style={{"background": "#FFFFFF", "color": "#0A2B33", "border": "1px solid #D8DFE3", "borderRadius": "14px", "padding": "12px 16px", "fontSize": "14px", "height": "46px", "width": "280px", "fontFamily": "inherit"}} />
          <small className={"mono"}>{"text · h46 · r 14px · bordo 1px solid #D8DFE3 · bg #FFFFFF"}</small>
        </div>
        <div className={"btn-cell"}>
          <input placeholder={"email"} style={{"background": "#FFFFFF", "color": "#0A2B33", "border": "1px solid #D8DFE3", "borderRadius": "14px", "padding": "12px 16px", "fontSize": "14px", "height": "46px", "width": "280px", "fontFamily": "inherit"}} />
          <small className={"mono"}>{"email · h46 · r 14px · bordo 1px solid #D8DFE3 · bg #FFFFFF"}</small>
        </div>
        <div className={"btn-cell"}>
          <input placeholder={"tel"} style={{"background": "#FFFFFF", "color": "#0A2B33", "border": "1px solid #D8DFE3", "borderRadius": "14px", "padding": "12px 16px", "fontSize": "14px", "height": "46px", "width": "280px", "fontFamily": "inherit"}} />
          <small className={"mono"}>{"tel · h46 · r 14px · bordo 1px solid #D8DFE3 · bg #FFFFFF"}</small>
        </div>
        <div className={"btn-cell"}>
          <textarea placeholder={"textarea"} style={{"background": "#FFFFFF", "color": "#0A2B33", "border": "1px solid #D8DFE3", "borderRadius": "14px", "padding": "12px 16px", "fontSize": "14px", "height": "126px", "width": "280px", "fontFamily": "inherit"}}></textarea>
          <small className={"mono"}>{"textarea · h126 · r 14px · bordo 1px solid #D8DFE3 · bg #FFFFFF"}</small>
        </div>
      </div>
    </section>
  )
}

function VisualEffects() {
  return (
    <section id={"fx"}>
      <div className={"cols"}>
        <div>
          <h2>{"Raggi"}</h2>
          <div className={"rads"}>
            <div className={"rad"}>
              <div style={{"borderRadius": "14px"}}></div>
              <code>{"14px"}</code>
              <small>{"93 elementi"}</small>
            </div>
            <div className={"rad"}>
              <div style={{"borderRadius": "9999px"}}></div>
              <code>{"9999px"}</code>
              <small>{"51 elementi"}</small>
            </div>
            <div className={"rad"}>
              <div style={{"borderRadius": "18px"}}></div>
              <code>{"18px"}</code>
              <small>{"50 elementi"}</small>
            </div>
            <div className={"rad"}>
              <div style={{"borderRadius": "22px"}}></div>
              <code>{"22px"}</code>
              <small>{"11 elementi"}</small>
            </div>
          </div>
        </div>
        <div>
          <h2>{"Ombre"}</h2>
          <div className={"shds"}>
            <div className={"shd"}>
              <div style={{"boxShadow": "#0033330A 0px 1px 2px 0px, #1133330F 0px 4px 12px -2px"}}></div>
              <small className={"mono"}>{"#0033330A 0px 1px 2px 0px, #1133330F 0px 4px 12px -2px"}</small>
              <small>{"64×"}</small>
            </div>
            <div className={"shd"}>
              <div style={{"boxShadow": "#00C38233 0px 0px 0px 1px"}}></div>
              <small className={"mono"}>{"#00C38233 0px 0px 0px 1px"}</small>
              <small>{"21×"}</small>
            </div>
            <div className={"shd"}>
              <div style={{"boxShadow": "#00C38340 0px 4px 6px -1px, #00C38340 0px 2px 4px -2px"}}></div>
              <small className={"mono"}>{"#00C38340 0px 4px 6px -1px, #00C38340 0px 2px 4px -2px"}</small>
              <small>{"7×"}</small>
            </div>
            <div className={"shd"}>
              <div style={{"boxShadow": "#00C3814D 0px 10px 15px -3px, #00C3814D 0px 4px 6px -4px"}}></div>
              <small className={"mono"}>{"#00C3814D 0px 10px 15px -3px, #00C3814D 0px 4px 6px -4px"}</small>
              <small>{"1×"}</small>
            </div>
            <div className={"shd"}>
              <div style={{"boxShadow": "#00C38266 0px 20px 25px -5px, #00C38266 0px 8px 10px -6px"}}></div>
              <small className={"mono"}>{"#00C38266 0px 20px 25px -5px, #00C38266 0px 8px 10px -6px"}</small>
              <small>{"1×"}</small>
            </div>
            <div className={"shd"}>
              <div style={{"boxShadow": "#00C38233 0px 4px 6px -1px, #00C38233 0px 2px 4px -2px"}}></div>
              <small className={"mono"}>{"#00C38233 0px 4px 6px -1px, #00C38233 0px 2px 4px -2px"}</small>
              <small>{"1×"}</small>
            </div>
            <div className={"shd"}>
              <div style={{"boxShadow": "#0000001A 0px 1px 3px 0px, #0000001A 0px 1px 2px -1px"}}></div>
              <small className={"mono"}>{"#0000001A 0px 1px 3px 0px, #0000001A 0px 1px 2px -1px"}</small>
              <small>{"1×"}</small>
            </div>
          </div>
        </div>
      </div>
      <h3>{"Gradienti e texture"}</h3>
      <div className={"shds"}>
        <div className={"shd"}>
          <div style={{"background": "radial-gradient(at 50% 0%, #00BF8024, #00000000 60%)", "border": "1px solid #e4e7ec"}}></div>
          <small className={"mono"}>{"radial-gradient(at 50% 0%, #00BF8024, #00000000 60%)"}</small>
        </div>
        <div className={"shd"}>
          <div style={{"background": "linear-gradient(to right, #1133330F 1px, #00000000 1px), linear-gradient(#1133330F 1px, #00000000 1px)", "border": "1px solid #e4e7ec"}}></div>
          <small className={"mono"}>{"linear-gradient(to right, #1133330F 1px, #00000000 1px), linear-gradient(#1133330F 1px, #00000000 1px)"}</small>
        </div>
        <div className={"shd"}>
          <div style={{"background": "radial-gradient(at 50% 0%, #00C3814D, #00000000 60%)", "border": "1px solid #e4e7ec"}}></div>
          <small className={"mono"}>{"radial-gradient(at 50% 0%, #00C3814D, #00000000 60%)"}</small>
        </div>
        <div className={"shd"}>
          <div style={{"background": "linear-gradient(to right bottom, #00C4801A 0%, #FFFFFF 50%, #FFFFFF 100%)", "border": "1px solid #e4e7ec"}}></div>
          <small className={"mono"}>{"linear-gradient(to right bottom, #00C4801A 0%, #FFFFFF 50%, #FFFFFF 100%)"}</small>
        </div>
      </div>
    </section>
  )
}

function Layout() {
  return (
    <section id={"layout"}>
      <h2>{"Layout, icone, movimento"}</h2>
      <ul>
        <li>
          <b>{"Container max-width:"}</b>
          {" 768px (10), 1280px (8), 896px (2), 1024px (1), 1152px (1)"}
        </li>
        <li>
          <b>{"Padding verticale sezioni:"}</b>
          {" 112px / 112px (8), 80px / 80px (2), 0px / 0px (1)"}
        </li>
        <li>
          <b>{"Gap flex/grid:"}</b>
          {" 8px (25), 12px (23), 16px (16), 6px (4), 20px (3), 28px (1), 24px (1), 40px (1)"}
        </li>
        <li>
          <b>{"Header:"}</b>
          {" altezza 64px desktop / 64px mobile · posizione sticky · sfondo #FFFFFFB2 · backdrop blur(12px) · bordo 0px #D8DFE3"}
        </li>
        <li>
          <b>{"Footer:"}</b>
          {" sfondo #0A2B33 · testo #FFFFFF"}
        </li>
        <li>
          <b>{"Icone:"}</b>
          {" 49 SVG, di cui 49 Lucide · stroke [['2', 49]] · award, arrow-right, circle-question-mark, circle-check, shield-check, scale, building2, building-2, bug, fingerprint-pattern, eye-off, scan-search, clipboard-list, activity, lock, search, camera, landmark, heart-pulse, factory, zap, shopping-bag, briefcase, hand-heart"}
        </li>
        <li>
          <b>{"Transizioni/animazioni:"}</b>
          {" 0.15s cubic-bezier(0.4, 0, 0.2, 1) (33), 0.3s cubic-bezier(0.4, 0, 0.2, 1) (1)"}
        </li>
        <li>
          <b>{"Variabili CSS:"}</b>
          {" 109 in totale, 31 custom (le default di Tailwind sono escluse)"}
        </li>
      </ul>
    </section>
  )
}

function CssVariables() {
  return (
    <section id={"vars"}>
      <h2>{"Variabili CSS custom"}</h2>
      <table>
        <tbody>
          <tr>
            <th>{"token"}</th>
            <th>{"selettore"}</th>
            <th>{"valore"}</th>
          </tr>
          <tr>
            <td>
              <code>{"--font-sans"}</code>
            </td>
            <td className={"muted"}>{":root, :host"}</td>
            <td>
              <code>{"\"Inter\", system-ui, -apple-system, sans-serif"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--color-background"}</code>
            </td>
            <td className={"muted"}>{":root, :host"}</td>
            <td>
              <code>{"var(--background)"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--color-foreground"}</code>
            </td>
            <td className={"muted"}>{":root, :host"}</td>
            <td>
              <code>{"var(--foreground)"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--color-border"}</code>
            </td>
            <td className={"muted"}>{":root, :host"}</td>
            <td>
              <code>{"var(--border)"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--color-ring"}</code>
            </td>
            <td className={"muted"}>{":root, :host"}</td>
            <td>
              <code>{"var(--ring)"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--font-display"}</code>
            </td>
            <td className={"muted"}>{":root, :host"}</td>
            <td>
              <code>{"\"Poppins\", \"Inter\", system-ui, sans-serif"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--radius"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <code>{".625rem"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--background"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              <code>{"#FFFFFF"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--foreground"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              <code>{"#0A2B33"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--surface"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#F5F9FA"}}></span>
              <code>{"#F5F9FA"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--surface-foreground"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              <code>{"#0A2B33"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--card"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              <code>{"#FFFFFF"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--card-foreground"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              <code>{"#0A2B33"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--popover"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              <code>{"#FFFFFF"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--popover-foreground"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              <code>{"#0A2B33"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--primary"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#00C483"}}></span>
              <code>{"#00C483"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--primary-foreground"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              <code>{"#FFFFFF"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--primary-hover"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#008B5B"}}></span>
              <code>{"#008B5B"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--secondary"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#EAF4F4"}}></span>
              <code>{"#EAF4F4"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--secondary-foreground"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              <code>{"#0A2B33"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--muted"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#F1F6F6"}}></span>
              <code>{"#F1F6F6"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--muted-foreground"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#55666F"}}></span>
              <code>{"#55666F"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--accent"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#E1F9EC"}}></span>
              <code>{"#E1F9EC"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--accent-foreground"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              <code>{"#0A2B33"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--destructive"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#DE3B3D"}}></span>
              <code>{"#DE3B3D"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--destructive-foreground"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              <code>{"#FFFFFF"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--border"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#D8DFE3"}}></span>
              <code>{"#D8DFE3"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--input"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#D8DFE3"}}></span>
              <code>{"#D8DFE3"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--ring"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#00C483"}}></span>
              <code>{"#00C483"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--ink"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#0A2B33"}}></span>
              <code>{"#0A2B33"}</code>
            </td>
          </tr>
          <tr>
            <td>
              <code>{"--ink-foreground"}</code>
            </td>
            <td className={"muted"}>{":root"}</td>
            <td>
              <span className={"dot"} style={{"background": "#FFFFFF"}}></span>
              <code>{"#FFFFFF"}</code>
            </td>
          </tr>
        </tbody>
      </table>
    </section>
  )
}
