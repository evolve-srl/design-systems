# PrivacyMasters Design System

Conversão da página italiana do design system para React, TypeScript e Vite.

```sh
npm install
npm run dev
```

Para compilar, corre `npm run build`.

Para mostrar as imagens locais referidas pelo HTML original, coloca estes ficheiros em `public/`.

- `desktop-fold.png`, `desktop-full.png`, `mobile-fold.png` e `mobile-full.png`
- `inner-1-fold.png`, `inner-1-full.png`, `inner-2-fold.png`, `inner-2-full.png`, `inner-3-fold.png` e `inner-3-full.png`
- `header.png`, `footer.png` e `logo-lockup.png`
